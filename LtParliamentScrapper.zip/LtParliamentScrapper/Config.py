
db = {
    'host': '192.168.0.199',
    'port': 3306,
    'db': 'parlament',
    'user': 'parl',
    'password': 'Pieputis123!'}